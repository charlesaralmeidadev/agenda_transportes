import ContainerVehicleTypes from 'components/containers/containerVehicleTypes'

const VehicleTypePage = () => <ContainerVehicleTypes />

export default VehicleTypePage
