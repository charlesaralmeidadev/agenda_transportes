import ContainerIntermediateDestinationInfo from 'components/containers/ContainerIntermediateDestinationInfo'

const PassengersPage = () => <ContainerIntermediateDestinationInfo />
export default PassengersPage
