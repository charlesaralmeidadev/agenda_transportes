import ContainerOtherInformations from 'components/containers/ContainerOtherInformations'

const BoardingInfoPage = () => <ContainerOtherInformations />

export default BoardingInfoPage
