import ContainerTransportTypes from 'components/containers/containerTransportTypes'

const TransportTypePage = () => <ContainerTransportTypes />

export default TransportTypePage
