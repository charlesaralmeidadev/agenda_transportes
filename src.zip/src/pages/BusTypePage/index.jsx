import ContainerBusTypes from 'components/containers/ContainerBusTypes'

const BusTypePage = () => <ContainerBusTypes />

export default BusTypePage
