import ContainerPassengersInfo from 'components/containers/ContainerPassengersInfo'

const PassengersPage = () => <ContainerPassengersInfo />

export default PassengersPage
