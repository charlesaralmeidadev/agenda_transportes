import ContainerBoardingInfo from 'components/containers/ContainerBoardingInfo'

const BoardingInfoPage = () => <ContainerBoardingInfo />

export default BoardingInfoPage
