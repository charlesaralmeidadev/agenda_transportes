import ContainerConfirmation from '../../components/containers/ContainerConfirmation'

const ConfirmationPage = () => <ContainerConfirmation />

export default ConfirmationPage
