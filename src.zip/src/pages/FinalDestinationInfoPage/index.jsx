import ContainerFinalDestinationInfo from 'components/containers/ContainerFinalDestinationInfo'

const FinalDestinationInfoPage = () => <ContainerFinalDestinationInfo />

export default FinalDestinationInfoPage
