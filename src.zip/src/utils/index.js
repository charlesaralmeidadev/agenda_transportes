export const openPage = (url) => {
    return () => window.open(url, '_blank')
}
